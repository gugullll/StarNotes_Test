'use strict';

/* =========================================================
   StarNote 原型 · 单文件交互逻辑
   依赖：无。浏览器直接打开即可。
   存储：File System Access API 写入本地 Markdown；
        不支持时退化为 localStorage 演示模式。
   ========================================================= */

const $ = (s, r = document) => r.querySelector(s);
const SVGNS = 'http://www.w3.org/2000/svg';
const NW = 168;   // 节点宽（与 CSS 变量一致）
const NH = 64;    // 节点高
const PRESETS = ['属于', '前置知识', '对比', '引用', '相关', '延伸'];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => 'n' + Math.random().toString(36).slice(2, 8);

const state = {
  nodes: new Map(),
  adj: new Map(),
  canvases: new Map(),
  activeCanvas: null,
  view: { x: 0, y: 0, k: 1 },
  selected: null,
  hovered: null,
  vault: null,
  search: '',
  link: null,
  editing: null,
  hoverTimer: null,
  hideTimer: null,
  saveTimer: null,
  canvasTimer: null,
};

const stage = $('#stage');
const viewport = $('#viewport');
const nodeLayer = $('#nodeLayer');
const edgeLayer = $('#edgeLayer');
const hovercard = $('#hovercard');
const ctxmenu = $('#ctxmenu');
const popover = $('#popover');

/* ============ 1. Markdown / Frontmatter ============ */

function parseNote(text) {
  const fm = { rel: [] };
  let body = text;
  const m = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?/.exec(text);
  if (m) {
    body = text.slice(m[0].length);
    let key = null, cur = null;
    for (const raw of m[1].split(/\r?\n/)) {
      const line = raw.replace(/\s+$/, '');
      if (!line.trim() || line.trim().startsWith('#')) continue;
      const topLevel = /^\S/.test(line);
      const mItem = /^\s*-\s*(.*)$/.exec(line);
      const mKV = /^\s*([A-Za-z_][\w-]*):\s*(.*)$/.exec(line);

      if (key === 'rel' && !topLevel) {
        if (mItem) {
          cur = {};
          fm.rel.push(cur);
          const kv = /^([A-Za-z_][\w-]*):\s*(.*)$/.exec(mItem[1]);
          if (kv) cur[kv[1]] = kv[2].trim();
        } else if (mKV && cur) {
          cur[mKV[1]] = mKV[2].trim();
        }
        continue;
      }
      if (mKV) {
        key = mKV[1];
        if (key === 'rel') { fm.rel = []; cur = null; }
        else fm[key] = unquote(mKV[2].trim());
      }
    }
  }
  return { fm, body };
}

function unquote(v) {
  if (/^".*"$/.test(v)) return v.slice(1, -1).replace(/\\"/g, '"');
  return v;
}
function quote(v) {
  return /[:#"'\n]|^\s|\s$/.test(v) ? '"' + String(v).replace(/"/g, '\\"') + '"' : v;
}

function serializeNote(n) {
  const out = ['---', 'id: ' + n.id, 'title: ' + quote(n.title)];
  if (n.links.length) {
    out.push('rel:');
    for (const l of n.links) {
      out.push('  - to: ' + l.to);
      if (l.type) out.push('    type: ' + quote(l.type));
      out.push('    dir: ' + (l.dir ? 1 : 0));
    }
  }
  out.push('---', '');
  return out.join('\n') + (n.body || '');
}

function parsePos(v) {
  if (!v) return null;
  const m = /^(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)$/.exec(String(v).trim());
  return m ? { x: +m[1], y: +m[2] } : null;
}

function inlineMd(t) {
  return esc(t)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/\[\[([^\]]+)\]\]/g, '<span class="wikilink">$1</span>')
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}

function renderMd(src) {
  const lines = String(src || '').split(/\r?\n/);
  let out = '', list = null, code = false, buf = [];
  const closeList = () => { if (list) { out += '</' + list + '>'; list = null; } };
  for (const line of lines) {
    if (/^```/.test(line)) {
      if (code) { out += '<pre><code>' + esc(buf.join('\n')) + '</code></pre>'; buf = []; code = false; }
      else { closeList(); code = true; }
      continue;
    }
    if (code) { buf.push(line); continue; }
    if (!line.trim()) { closeList(); continue; }
    let m;
    if ((m = /^(#{1,3})\s+(.*)$/.exec(line))) { closeList(); const h = m[1].length; out += `<h${h}>${inlineMd(m[2])}</h${h}>`; continue; }
    if (/^(-{3,}|\*{3,})$/.test(line.trim())) { closeList(); out += '<hr>'; continue; }
    if ((m = /^>\s?(.*)$/.exec(line))) { closeList(); out += `<blockquote>${inlineMd(m[1])}</blockquote>`; continue; }
    if ((m = /^\s*[-*+]\s+(.*)$/.exec(line))) { if (list !== 'ul') { closeList(); out += '<ul>'; list = 'ul'; } out += `<li>${inlineMd(m[1])}</li>`; continue; }
    if ((m = /^\s*\d+\.\s+(.*)$/.exec(line))) { if (list !== 'ol') { closeList(); out += '<ol>'; list = 'ol'; } out += `<li>${inlineMd(m[1])}</li>`; continue; }
    closeList();
    out += `<p>${inlineMd(line)}</p>`;
  }
  if (code) out += '<pre><code>' + esc(buf.join('\n')) + '</code></pre>';
  closeList();
  return out;
}

function summaryOf(n, len = 110) {
  const t = String(n.body || '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/[#>*_`~\-]+/g, ' ')
    .replace(/\[\[([^\]]+)\]\]/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
  return t.slice(0, len) + (t.length > len ? '…' : '');
}

function ago(ts) {
  if (!ts) return '未记录';
  const d = Date.now() - ts;
  if (d < 60e3) return '刚刚';
  if (d < 3600e3) return Math.round(d / 60e3) + ' 分钟前';
  if (d < 86400e3) return Math.round(d / 3600e3) + ' 小时前';
  return Math.round(d / 86400e3) + ' 天前';
}

/* ============ 2. 图数据辅助 ============ */

const isVisible = (n) => !!n.pos;
const visibleNodes = () => [...state.nodes.values()].filter(isVisible);

function buildAdj() {
  const adj = new Map();
  for (const n of state.nodes.values()) adj.set(n.id, new Set());
  for (const n of state.nodes.values()) {
    for (const l of n.links) {
      if (!state.nodes.has(l.to) || l.to === n.id) continue;
      adj.get(n.id).add(l.to);
      adj.get(l.to)?.add(n.id);
    }
  }
  state.adj = adj;
}

function neighbors(n) {
  const set = state.adj.get(n.id);
  if (!set) return [];
  const out = [];
  for (const id of set) {
    const m = state.nodes.get(id);
    if (m) out.push(m);
  }
  return out;
}

const degree = (n) => (state.adj.get(n.id)?.size || 0);
const hiddenNeighbors = (n) => neighbors(n).filter((m) => !isVisible(m));

/* ============ 2.5 多画布 ============
   笔记与关联是全局的（唯一真相在 .md 的 rel 里）；
   画布只记录「哪些笔记出现在这块板上、摆在哪个坐标」。
   换画布 = 换一套坐标，笔记内容与关系不受影响。
   ==================================== */

function parseCanvas(text, file) {
  const { fm, body } = parseNote(text);
  const placements = new Map();
  for (const line of body.split(/\r?\n/)) {
    const m = /^\s*[-*]\s+([A-Za-z0-9_-]+)\s+(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$/.exec(line);
    if (m) placements.set(m[1], { x: +m[2], y: +m[3] });
  }
  return {
    id: fm.id || 'c' + Math.random().toString(36).slice(2, 8),
    name: fm.name || file.replace(/\.canvas\.md$/i, ''),
    file,
    placements,
  };
}

function serializeCanvas(c) {
  const out = ['---', 'type: canvas', 'id: ' + c.id, 'name: ' + quote(c.name), '---', ''];
  for (const [id, p] of c.placements) out.push('- ' + id + ' ' + Math.round(p.x) + ' ' + Math.round(p.y));
  return out.join('\n') + '\n';
}

function canvasFileFor(c) {
  const base = (c.name || '画布').replace(/[\\/:*?"<>|\n]/g, '-').replace(/\s+/g, ' ').trim().slice(0, 50) || '画布';
  const used = new Set([...state.canvases.values()].filter((x) => x !== c).map((x) => x.file));
  let name = base + '.canvas.md', i = 2;
  while (used.has(name)) name = base + ' (' + (i++) + ').canvas.md';
  return name;
}

function snapshotActive() {
  const c = state.activeCanvas;
  if (!c) return;
  const p = new Map();
  for (const n of state.nodes.values()) if (n.pos) p.set(n.id, { x: n.pos.x, y: n.pos.y });
  c.placements = p;
}

async function writeCanvas(c) {
  if (!c) return;
  if (!state.vault) { saveDemo(); return; }
  try {
    const fh = await state.vault.getFileHandle(c.file, { create: true });
    const w = await fh.createWritable();
    await w.write(serializeCanvas(c));
    await w.close();
  } catch (err) {
    console.error(err);
    flash('画布保存失败：' + err.message);
  }
}

function touchCanvas() {
  snapshotActive();
  updateCanvasBtn();
  clearTimeout(state.canvasTimer);
  state.canvasTimer = setTimeout(() => writeCanvas(state.activeCanvas), 500);
}

function applyCanvas(c) {
  snapshotActive();
  state.activeCanvas = c;
  for (const n of state.nodes.values()) { n.pos = null; n.revealedBy.clear(); }
  for (const [id, p] of c.placements) {
    const n = state.nodes.get(id);
    if (n) { n.pos = { x: p.x, y: p.y }; n.revealedBy.clear(); }
  }
  state.selected = null;
  renderAll();
  updateCanvasBtn();
}

function switchCanvas(c) {
  if (!c || c === state.activeCanvas) return;
  snapshotActive();
  writeCanvas(state.activeCanvas);
  applyCanvas(c);
  fitView();
  closeCanvasMenu();
  if (!state.vault) saveDemo();
  flash('已切换到「' + c.name + '」');
}

function createCanvas(name) {
  const c = { id: 'c' + Math.random().toString(36).slice(2, 8), name: (name || '').trim() || '未命名画布', file: null, placements: new Map() };
  state.canvases.set(c.id, c);
  c.file = canvasFileFor(c);
  writeCanvas(c);
  switchCanvas(c);
  return c;
}

async function renameCanvas(c, name) {
  const next = (name || '').trim();
  if (!next || next === c.name) return;
  const oldFile = c.file;
  c.name = next;
  const newFile = canvasFileFor(c);
  if (newFile !== oldFile) {
    c.file = newFile;
    await writeCanvas(c);
    if (state.vault) { try { await state.vault.removeEntry(oldFile); } catch (e) { /* ignore */ } }
  } else {
    await writeCanvas(c);
  }
  updateCanvasBtn();
  renderCanvasMenu();
}

async function deleteCanvas(c) {
  if (state.canvases.size <= 1) { flash('至少保留一块画布'); return; }
  if (!confirm('删除画布「' + c.name + '」？\n画布上的笔记不会删除，只是不再出现在这块板上。')) return;
  const wasActive = c === state.activeCanvas;
  state.canvases.delete(c.id);
  if (state.vault && c.file) { try { await state.vault.removeEntry(c.file); } catch (e) { /* ignore */ } }
  if (wasActive) {
    const next = state.canvases.values().next().value;
    applyCanvas(next);
    fitView();
  }
  renderCanvasMenu();
  flash('已删除画布');
}

function updateCanvasBtn() {  const c = state.activeCanvas;
  const btn = $('#btnCanvas');
  if (!btn) return;
  btn.querySelector('.cname').textContent = c ? c.name : '未选择画布';
  btn.querySelector('.ccount').textContent = c ? c.placements.size : 0;
}

/* ---- 通用输入对话框 ---- */
let askResolve = null;
function askText(title, value) {
  return new Promise((resolve) => {
    askResolve = resolve;
    $('#askTitle').textContent = title;
    $('#askInput').value = value || '';
    $('#askMask').classList.add('show');
    setTimeout(() => { $('#askInput').focus(); $('#askInput').select(); }, 30);
  });
}
function closeAsk(val) {
  $('#askMask').classList.remove('show');
  const r = askResolve;
  askResolve = null;
  if (r) r(val);
}

function bindAsk() {
  $('#askOk').addEventListener('click', () => closeAsk($('#askInput').value.trim()));
  $('#askCancel').addEventListener('click', () => closeAsk(null));
  $('#askInput').addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') { ev.preventDefault(); ev.stopPropagation(); closeAsk($('#askInput').value.trim()); }
    if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); closeAsk(null); }
  });
  $('#askMask').addEventListener('pointerdown', (ev) => {
    if (ev.target === $('#askMask')) closeAsk(null);
  });
}

function renderCanvasMenu() {
  const menu = $('#canvasMenu');
  if (!menu) return;
  const items = [...state.canvases.values()].map((c) =>
    '<div class="cm-item' + (c === state.activeCanvas ? ' on' : '') + '" data-id="' + c.id + '">' +
      '<span class="cm-name">' + esc(c.name) + '</span>' +
      '<span class="cm-n">' + c.placements.size + '</span>' +
      '<span class="cm-acts">' +
        '<button class="ghost cm-rename" data-id="' + c.id + '">改名</button>' +
        (state.canvases.size > 1 ? '<button class="ghost danger cm-del" data-id="' + c.id + '">删除</button>' : '') +
      '</span>' +
    '</div>').join('');
  menu.innerHTML =
    '<div class="cm-head">画布 <span>' + state.canvases.size + '</span></div>' +
    '<div class="cm-list">' + items + '</div>' +
    '<div class="cm-foot"><button class="primary" id="cmNew">+ 新建画布</button></div>';
}

function openCanvasMenu() {
  renderCanvasMenu();
  const menu = $('#canvasMenu');
  const r = $('#btnCanvas').getBoundingClientRect();
  menu.style.left = Math.min(r.left, window.innerWidth - 300) + 'px';
  menu.style.top = (r.bottom + 6) + 'px';
  menu.classList.add('show');
}
function closeCanvasMenu() { $('#canvasMenu').classList.remove('show'); }

/* ============ 3. 渲染 ============ */

function renderAll() {
  buildAdj();
  for (const n of state.nodes.values()) paintNode(n);
  renderEdges();
  renderStats();
  applyView();
}

function nodeEl(n) {
  if (n.el) return n.el;
  const el = document.createElement('div');
  el.className = 'node';
  el.dataset.id = n.id;
  el.innerHTML = '<div class="node-title"></div><div class="node-meta"></div><div class="handle" title="拖拽到另一个节点建立关联"></div>';
  el.addEventListener('mouseenter', () => {
    if (state.link) return;
    clearTimeout(state.hoverTimer);
    state.hoverTimer = setTimeout(() => showHover(n, el), 320);
  });
  el.addEventListener('mouseleave', (ev) => {
    clearTimeout(state.hoverTimer);
    if (ev.relatedTarget && hovercard.contains(ev.relatedTarget)) return;
    scheduleHideHover();
  });
  nodeLayer.appendChild(el);
  n.el = el;
  return el;
}

function paintNode(n) {
  const el = nodeEl(n);
  const vis = isVisible(n);
  el.style.display = vis ? '' : 'none';
  if (!vis) return;
  el.style.left = (n.pos.x - NW / 2) + 'px';
  el.style.top = (n.pos.y - NH / 2) + 'px';
  el.classList.toggle('selected', state.selected === n.id);
  const q = state.search.trim().toLowerCase();
  el.classList.toggle('dim', !!q && !(n.title + ' ' + (n.body || '')).toLowerCase().includes(q));
  el.querySelector('.node-title').textContent = n.title || '未命名';
  const hidden = hiddenNeighbors(n).length;
  el.querySelector('.node-meta').innerHTML =
    '<span>' + degree(n) + ' 关联</span>' +
    (hidden ? '<span class="node-more">+' + hidden + '</span>' : '');
}

function anchor(from, to) {
  const dx = to.pos.x - from.pos.x;
  const dy = to.pos.y - from.pos.y;
  const adx = Math.abs(dx) || 1e-4;
  const ady = Math.abs(dy) || 1e-4;
  const t = Math.min((NW / 2 + 6) / adx, (NH / 2 + 6) / ady);
  return { x: from.pos.x + dx * t, y: from.pos.y + dy * t };
}

function renderEdges() {
  edgeLayer.textContent = '';
  const vis = visibleNodes();
  const seen = new Set();
  for (const n of vis) {
    n.links.forEach((l, idx) => {
      const t = state.nodes.get(l.to);
      if (!t || !isVisible(t)) return;
      const key = [n.id, t.id].sort().join('~') + '~' + (l.type || '');
      if (seen.has(key)) return;
      seen.add(key);
      edgeLayer.appendChild(edgeEl(n, t, l, idx));
    });
  }
}

function edgeEl(a, b, l, idx) {
  const s = anchor(a, b);
  const e = anchor(b, a);
  const dx = e.x - s.x, dy = e.y - s.y;
  const len = Math.hypot(dx, dy) || 1;
  const off = Math.min(26, len * 0.09);
  const cx = (s.x + e.x) / 2 - (dy / len) * off;
  const cy = (s.y + e.y) / 2 + (dx / len) * off;

  const hot = state.selected === a.id || state.selected === b.id || state.hovered === a.id || state.hovered === b.id;

  const p = document.createElementNS(SVGNS, 'path');
  p.setAttribute('class', 'wire' + (hot ? ' hot' : ''));
  p.setAttribute('d', `M ${s.x.toFixed(1)} ${s.y.toFixed(1)} Q ${cx.toFixed(1)} ${cy.toFixed(1)} ${e.x.toFixed(1)} ${e.y.toFixed(1)}`);
  p.dataset.src = a.id;
  p.dataset.idx = idx;
  if (l.dir) p.setAttribute('marker-end', hot ? 'url(#arrow-hot)' : 'url(#arrow)');

  if (!hot || !l.type) return p;

  const g = document.createElementNS(SVGNS, 'g');
  g.setAttribute('pointer-events', 'none');
  const mx = s.x * 0.25 + cx * 0.5 + e.x * 0.25;
  const my = s.y * 0.25 + cy * 0.5 + e.y * 0.25;
  const w = l.type.length * 11 + 14;
  const rect = document.createElementNS(SVGNS, 'rect');
  rect.setAttribute('x', mx - w / 2);
  rect.setAttribute('y', my - 9);
  rect.setAttribute('width', w);
  rect.setAttribute('height', 17);
  rect.setAttribute('rx', 8.5);
  rect.setAttribute('fill', '#eeedfe');
  const text = document.createElementNS(SVGNS, 'text');
  text.setAttribute('x', mx);
  text.setAttribute('y', my + 2);
  text.setAttribute('text-anchor', 'middle');
  text.setAttribute('dominant-baseline', 'middle');
  text.setAttribute('font-size', '11');
  text.setAttribute('fill', '#3c3489');
  text.textContent = l.type;

  const wrap = document.createElementNS(SVGNS, 'g');
  wrap.appendChild(p);
  g.appendChild(rect);
  g.appendChild(text);
  wrap.appendChild(g);
  return wrap;
}

function renderStats() {
  const vis = visibleNodes();
  $('#statNodes').textContent = vis.length + ' 节点';
  let links = 0;
  const seen = new Set();
  for (const n of vis) {
    for (const l of n.links) {
      const t = state.nodes.get(l.to);
      if (!t || !isVisible(t)) continue;
      const k = [n.id, t.id].sort().join('~') + '~' + (l.type || '');
      if (seen.has(k)) continue;
      seen.add(k); links++;
    }
  }
  $('#statLinks').textContent = links + ' 关联';

  const hidden = [...state.nodes.values()].filter((n) => !isVisible(n)).length;
  const chip = $('#hiddenChip');
  chip.classList.toggle('show', hidden > 0);
  chip.textContent = hidden > 0 ? hidden + ' 篇未上本画布 · 全部展开' : '';
  chip.title = '这些笔记存在于库中，但当前画布没有摆放它们';
  chip.onclick = () => { revealAll(); };
}

/* ============ 4. 视图变换 ============ */

function applyView() {
  const v = state.view;
  viewport.style.transform = `translate(${v.x}px, ${v.y}px) scale(${v.k})`;
  $('#statZoom').textContent = Math.round(v.k * 100) + '%';
}

function toWorld(clientX, clientY) {
  const r = stage.getBoundingClientRect();
  return { x: (clientX - r.left - state.view.x) / state.view.k, y: (clientY - r.top - state.view.y) / state.view.k };
}

function fitView() {
  const vis = visibleNodes();
  if (!vis.length) return;
  let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
  for (const n of vis) {
    x1 = Math.min(x1, n.pos.x - NW / 2); x2 = Math.max(x2, n.pos.x + NW / 2);
    y1 = Math.min(y1, n.pos.y - NH / 2); y2 = Math.max(y2, n.pos.y + NH / 2);
  }
  const r = stage.getBoundingClientRect();
  const pad = 110;
  const k = clamp(Math.min((r.width - pad * 2) / Math.max(x2 - x1, 1), (r.height - pad * 2) / Math.max(y2 - y1, 1)), 0.25, 1.1);
  state.view = { k, x: r.width / 2 - ((x1 + x2) / 2) * k, y: r.height / 2 - ((y1 + y2) / 2) * k };
  applyView();
}

function focusOn(n) {
  const r = stage.getBoundingClientRect();
  state.view.x = r.width / 2 - n.pos.x * state.view.k;
  state.view.y = r.height / 2 - n.pos.y * state.view.k;
  applyView();
}

/* ============ 5. 展开 / 收起 ============ */

function reveal(m, parent, i, total) {
  if (!m.pos) {
    const seed = (parent.id.charCodeAt(2) || 3) % 7;
    const angle = -Math.PI / 2 + (i / Math.max(total, 1)) * Math.PI * 2 + seed * 0.12;
    const dist = 250 + (i % 3) * 45;
    m.pos = { x: parent.pos.x + Math.cos(angle) * dist, y: parent.pos.y + Math.sin(angle) * dist };
  }
  m.revealedBy.add(parent.id);
}

function toggleExpand(n) {
  const hidden = hiddenNeighbors(n);
  if (!hidden.length) return;
  hidden.forEach((m, i) => reveal(m, n, i, hidden.length));
  renderAll();
  touchCanvas();
}

function collapseFrom(n) {
  for (const m of neighbors(n)) {
    if (!m.revealedBy.has(n.id)) continue;
    m.revealedBy.delete(n.id);
    if (m.revealedBy.size === 0) m.pos = null;
  }
}

function revealAll() {
  const hidden = [...state.nodes.values()].filter((n) => !isVisible(n));
  let i = 0;
  for (const n of hidden) {
    const angle = i * 2.39996;
    const r = 90 * Math.sqrt(i + 1) + 160;
    n.pos = n.pos || { x: 900 + Math.cos(angle) * r, y: 640 + Math.sin(angle) * r };
    i++;
  }
  renderAll();
  fitView();
  touchCanvas();
}

/* ============ 6. 选中 / 悬浮预览 / 菜单 ============ */

function select(id) {
  if (state.selected === id) { renderAll(); return; }
  state.selected = id;
  renderAll();
}

function showHover(n, el) {
  const r = el.getBoundingClientRect();
  hovercard.innerHTML =
    '<h4>' + esc(n.title || '未命名') + '</h4>' +
    '<p>' + (esc(summaryOf(n)) || '<span style="color:var(--text-3)">还没有内容，右键可打开编辑</span>') + '</p>' +
    '<div class="row"><span>' + degree(n) + ' 条关联</span><span>·</span><span>' + ago(n.updated) + '</span><span class="spacer"></span>' +
    '<button class="ghost" data-open="' + n.id + '">打开笔记</button></div>';
  hovercard.classList.add('show');
  const h = hovercard.offsetHeight;
  let left = r.right + 14;
  if (left + 292 > window.innerWidth) left = r.left - 292;
  let top = r.top - 4;
  if (top + h > window.innerHeight - 14) top = window.innerHeight - h - 14;
  hovercard.style.left = Math.max(12, left) + 'px';
  hovercard.style.top = Math.max(60, top) + 'px';
  clearTimeout(state.hideTimer);
  hovercard.onmouseenter = () => clearTimeout(state.hideTimer);
  hovercard.onmouseleave = scheduleHideHover;
  hovercard.querySelector('[data-open]')?.addEventListener('click', () => {
    const t = state.nodes.get(n.id);
    hideHover();
    if (t) openEditor(t);
  });
}

function scheduleHideHover() {
  clearTimeout(state.hideTimer);
  state.hideTimer = setTimeout(hideHover, 200);
}
function hideHover() {
  hovercard.classList.remove('show');
}

function showMenu(x, y, n) {
  const hidden = hiddenNeighbors(n).length;
  const canCollapse = neighbors(n).some((m) => m.revealedBy.has(n.id));
  const inOthers = [...state.canvases.values()].filter((c) => c !== state.activeCanvas && c.placements.has(n.id));
  ctxmenu.innerHTML =
    '<div class="item" data-act="open">打开笔记<span class="k">双击</span></div>' +
    '<div class="item" data-act="expand">' + (hidden ? '展开关联 (' + hidden + ')' : '展开关联') + '</div>' +
    (canCollapse ? '<div class="item" data-act="collapse">收起关联</div>' : '') +
    '<div class="hr"></div>' +
    '<div class="item" data-act="rename">重命名</div>' +
    (n.pos ? '<div class="item" data-act="detach">从本画布移除</div>' : '<div class="item" data-act="attach">放到本画布</div>') +
    (inOthers.length ? '<div class="item" data-act="jump">在「' + esc(inOthers[0].name) + '」中查看</div>' : '') +
    '<div class="hr"></div>' +
    '<div class="item danger" data-act="delete">删除笔记文件</div>';
  ctxmenu.style.left = Math.min(x, window.innerWidth - 220) + 'px';
  ctxmenu.style.top = Math.min(y, window.innerHeight - 300) + 'px';
  ctxmenu.classList.add('show');
  ctxmenu.dataset.id = n.id;
}

function closeMenu() { ctxmenu.classList.remove('show'); }
function closePopover() { popover.classList.remove('show'); }

/* ============ 7. 建立关联 ============ */

function startLink(n, ev) {
  const p = document.createElementNS(SVGNS, 'path');
  p.setAttribute('class', 'temp');
  edgeLayer.appendChild(p);
  state.link = { from: n, path: p };
  stage.classList.add('linking');
  hideHover();
  moveLink(ev);
}

function moveLink(ev) {
  const w = toWorld(ev.clientX, ev.clientY);
  const s = anchor(state.link.from, { pos: w });
  state.link.path.setAttribute('d', `M ${s.x.toFixed(1)} ${s.y.toFixed(1)} L ${w.x.toFixed(1)} ${w.y.toFixed(1)}`);
}

function finishLink(ev) {
  const from = state.link.from;
  state.link.path.remove();
  state.link = null;
  stage.classList.remove('linking');
  const el = document.elementFromPoint(ev.clientX, ev.clientY);
  const hit = el && el.closest ? el.closest('.node') : null;
  if (!hit) return;
  const to = state.nodes.get(hit.dataset.id);
  if (!to || to.id === from.id) return;
  if (from.links.some((l) => l.to === to.id)) { flash('两个节点之间已经有关联了'); return; }
  openRelation(from, to, ev.clientX, ev.clientY);
}

function openRelation(from, to, x, y) {
  popover.innerHTML =
    '<div class="plabel">' + esc(from.title) + ' → ' + esc(to.title) + '</div>' +
    '<input id="relInput" type="text" value="相关" style="width:100%" placeholder="关系名称">' +
    '<div class="chips" id="relChips">' + PRESETS.map((p) => '<span class="chip' + (p === '相关' ? ' on' : '') + '" data-t="' + p + '">' + p + '</span>').join('') + '</div>' +
    '<label style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-2)"><input type="checkbox" id="relDir" checked> 有向（A → B）</label>' +
    '<div class="foot"><span class="spacer"></span><button class="ghost" id="relCancel">取消</button><button class="primary" id="relOk">建立关联</button></div>';
  popover.style.left = Math.min(x, window.innerWidth - 266) + 'px';
  popover.style.top = Math.min(y, window.innerHeight - 226) + 'px';
  popover.classList.add('show');

  const input = $('#relInput');
  input.focus();
  input.select();

  $('#relChips').addEventListener('click', (ev) => {
    const chip = ev.target.closest('.chip');
    if (!chip) return;
    [...$('#relChips').children].forEach((c) => c.classList.toggle('on', c === chip));
    input.value = chip.dataset.t;
  });

  const commit = () => {
    const type = input.value.trim() || '相关';
    from.links.push({ to: to.id, type, dir: $('#relDir').checked ? 1 : 0 });
    from.dirty = true;
    persist(from);
    closePopover();
    select(from.id);
    flash('已建立关联：' + type);
  };

  $('#relOk').addEventListener('click', commit);
  $('#relCancel').addEventListener('click', closePopover);
  input.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') commit();
    if (ev.key === 'Escape') closePopover();
  });
}

/* ============ 8. 画布交互 ============ */

let drag = null;

stage.addEventListener('pointerdown', (ev) => {
  if (ev.button === 2) return;
  closeMenu(); closePopover(); hideHover();

  const handle = ev.target.closest('.handle');
  const nodeHit = ev.target.closest('.node');
  const wire = ev.target.closest('path.wire');

  if (handle && nodeHit) {
    startLink(state.nodes.get(nodeHit.dataset.id), ev);
    return;
  }
  if (nodeHit) {
    const n = state.nodes.get(nodeHit.dataset.id);
    drag = { type: 'node', n, sx: ev.clientX, sy: ev.clientY, ox: n.pos.x, oy: n.pos.y, moved: false };
    stage.setPointerCapture(ev.pointerId);
    select(n.id);
    return;
  }
  if (wire) {
    select(state.nodes.get(wire.dataset.src)?.id || null);
    return;
  }
  drag = { type: 'pan', sx: ev.clientX, sy: ev.clientY, ox: state.view.x, oy: state.view.y, moved: false };
  stage.setPointerCapture(ev.pointerId);
  select(null);
});

window.addEventListener('pointermove', (ev) => {
  if (state.link) { moveLink(ev); return; }
  if (!drag) return;
  const dx = ev.clientX - drag.sx;
  const dy = ev.clientY - drag.sy;
  if (!drag.moved && Math.hypot(dx, dy) > 3) {
    drag.moved = true;
    if (drag.type === 'pan') stage.classList.add('panning');
  }
  if (!drag.moved) return;
  if (drag.type === 'pan') {
    state.view.x = drag.ox + dx;
    state.view.y = drag.oy + dy;
    applyView();
  } else {
    drag.n.pos.x = drag.ox + dx / state.view.k;
    drag.n.pos.y = drag.oy + dy / state.view.k;
    paintNode(drag.n);
    renderEdges();
  }
});

window.addEventListener('pointerup', (ev) => {
  if (state.link) { finishLink(ev); return; }
  if (!drag) return;
  const d = drag;
  drag = null;
  stage.classList.remove('panning');
  if (d.type === 'node') {
    if (!d.moved) toggleExpand(d.n);
    else {
      d.n.revealedBy.clear();
      d.n.dirty = true;
      touchCanvas();
    }
  }
});

stage.addEventListener('wheel', (ev) => {
  ev.preventDefault();
  const r = stage.getBoundingClientRect();
  const px = ev.clientX - r.left;
  const py = ev.clientY - r.top;
  const wx = (px - state.view.x) / state.view.k;
  const wy = (py - state.view.y) / state.view.k;
  const dy = Number.isFinite(ev.deltaY) ? ev.deltaY : 0;
  const factor = Math.exp(-dy * 0.0016);
  const k = clamp(state.view.k * factor, 0.2, 2.6);
  state.view.k = k;
  state.view.x = px - wx * k;
  state.view.y = py - wy * k;
  applyView();
}, { passive: false });

stage.addEventListener('dblclick', (ev) => {
  const nodeHit = ev.target.closest('.node');
  if (nodeHit) {
    const n = state.nodes.get(nodeHit.dataset.id);
    if (n) openEditor(n);
    return;
  }
  if (ev.target.closest('path.wire')) return;
  createNote(toWorld(ev.clientX, ev.clientY));
});

nodeLayer.addEventListener('contextmenu', (ev) => {
  const el = ev.target.closest('.node');
  if (!el) return;
  ev.preventDefault();
  const n = state.nodes.get(el.dataset.id);
  select(n.id);
  showMenu(ev.clientX, ev.clientY, n);
});

edgeLayer.addEventListener('contextmenu', (ev) => {
  const p = ev.target.closest('path.wire');
  if (!p) return;
  ev.preventDefault();
  const src = state.nodes.get(p.dataset.src);
  const l = src && src.links[+p.dataset.idx];
  if (!l) return;
  const target = state.nodes.get(l.to);
  if (!confirm('删除这条关联？\n' + src.title + ' —' + (l.type ? '(' + l.type + ')— ' : '— ') + (target ? target.title : l.to))) return;
  src.links.splice(+p.dataset.idx, 1);
  src.dirty = true;
  persist(src);
  renderAll();
});

ctxmenu.addEventListener('click', async (ev) => {
  const item = ev.target.closest('.item');
  if (!item) return;
  const n = state.nodes.get(ctxmenu.dataset.id);
  closeMenu();
  if (!n) return;
  const act = item.dataset.act;
  if (act === 'open') openEditor(n);
  if (act === 'expand') { const h = hiddenNeighbors(n); h.forEach((m, i) => reveal(m, n, i, h.length)); renderAll(); touchCanvas(); }
  if (act === 'collapse') { collapseFrom(n); renderAll(); touchCanvas(); }
  if (act === 'rename') { openEditor(n); $('#editTitle').focus(); $('#editTitle').select(); }
  if (act === 'detach') { n.pos = null; n.revealedBy.clear(); renderAll(); touchCanvas(); }
  if (act === 'attach') {
    const r = stage.getBoundingClientRect();
    n.pos = { x: (r.width / 2 - state.view.x) / state.view.k, y: (r.height / 2 - state.view.y) / state.view.k };
    renderAll();
    touchCanvas();
  }
  if (act === 'jump') {
    const other = [...state.canvases.values()].find((c) => c !== state.activeCanvas && c.placements.has(n.id));
    if (other) { switchCanvas(other); setTimeout(() => { select(n.id); focusOn(n); }, 60); }
  }
  if (act === 'delete') await deleteNote(n);
});

document.addEventListener('pointerdown', (ev) => {
  if (!ctxmenu.contains(ev.target)) closeMenu();
  if (!popover.contains(ev.target) && !ev.target.closest('.handle')) closePopover();
  if (!ev.target.closest('#canvasMenu') && !ev.target.closest('#btnCanvas')) closeCanvasMenu();
}, true);

/* ============ 9. 编辑器 ============ */

function openEditor(n) {
  state.editing = n;
  $('#editTitle').value = n.title || '';
  $('#editBody').value = n.body || '';
  $('#editor').classList.add('open');
  $('#editSaved').textContent = '未修改';
  $('#editMeta').textContent = degree(n) + ' 条关联 · ' + (n.file || '尚未保存到磁盘');
  switchTab('write');
  setTimeout(() => $('#editBody').focus(), 60);
}

function switchTab(tab) {
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('on', t.dataset.tab === tab));
  $('#editBody').style.display = tab === 'write' ? '' : 'none';
  $('#editPreview').style.display = tab === 'read' ? '' : 'none';
  if (tab === 'read') $('#editPreview').innerHTML = renderMd($('#editBody').value);
}

function closeEditor() {
  if (state.editing) persist(state.editing);
  $('#editor').classList.remove('open');
  state.editing = null;
  renderAll();
}

async function saveEditor() {
  const n = state.editing;
  if (!n) return;
  const newTitle = $('#editTitle').value.trim() || '未命名';
  const newBody = $('#editBody').value;
  const renamed = newTitle !== n.title;
  n.title = newTitle;
  n.body = newBody;
  n.updated = Date.now();
  await persist(n, renamed);
  $('#editSaved').textContent = '已保存';
  $('#editMeta').textContent = degree(n) + ' 条关联 · ' + (n.file || '演示模式');
  renderAll();
}

document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));
$('#btnSave').addEventListener('click', saveEditor);
$('#btnCloseEditor').addEventListener('click', closeEditor);
$('#editTitle').addEventListener('input', () => { $('#editSaved').textContent = '有未保存修改'; });
$('#editBody').addEventListener('input', () => {
  $('#editSaved').textContent = '有未保存修改';
  if (document.querySelector('.tab.on')?.dataset.tab === 'read') {
    $('#editPreview').innerHTML = renderMd($('#editBody').value);
  }
});

/* ============ 10. 持久化 ============ */

function fileFor(n) {
  const base = (n.title || '未命名').replace(/[\\/:*?"<>|\n]/g, '-').replace(/\s+/g, ' ').trim().slice(0, 60) || '未命名';
  const used = new Set([...state.nodes.values()].filter((x) => x !== n).map((x) => x.file));
  let name = base + '.md', i = 2;
  while (used.has(name)) name = base + ' (' + (i++) + ').md';
  return name;
}

async function persist(n, renamed) {
  n.updated = Date.now();
  if (!state.vault) { saveDemo(); return; }
  const old = n.file;
  if (renamed || !n.file) n.file = fileFor(n);
  try {
    const fh = await state.vault.getFileHandle(n.file, { create: true });
    const w = await fh.createWritable();
    await w.write(serializeNote(n));
    await w.close();
    if (renamed && old && old !== n.file) {
      try { await state.vault.removeEntry(old); } catch (e) { /* 旧文件可能已不存在 */ }
    }
  } catch (err) {
    console.error(err);
    flash('写入失败：' + err.message);
  }
}

async function deleteNote(n) {
  if (!confirm('删除「' + n.title + '」？\n对应 Markdown 文件会一起删除，且不可撤销。')) return;
  for (const m of state.nodes.values()) m.links = m.links.filter((l) => l.to !== n.id);
  for (const c of state.canvases.values()) c.placements.delete(n.id);
  state.nodes.delete(n.id);
  n.el?.remove();
  if (state.vault && n.file) {
    try { await state.vault.removeEntry(n.file); } catch (e) { /* ignore */ }
    await writeCanvas(state.activeCanvas);
  } else {
    saveDemo();
  }
  if (state.selected === n.id) state.selected = null;
  renderAll();
  updateCanvasBtn();
  flash('已删除');
}

/* ---- IndexedDB 保存目录句柄 ---- */
function idb() {
  return new Promise((res, rej) => {
    const req = indexedDB.open('starnote', 1);
    req.onupgradeneeded = () => req.result.createObjectStore('kv');
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}
async function idbSet(k, v) {
  const db = await idb();
  return new Promise((res, rej) => {
    const tx = db.transaction('kv', 'readwrite');
    tx.objectStore('kv').put(v, k);
    tx.oncomplete = res;
    tx.onerror = () => rej(tx.error);
  });
}
async function idbGet(k) {
  const db = await idb();
  return new Promise((res) => {
    const tx = db.transaction('kv', 'readonly');
    const r = tx.objectStore('kv').get(k);
    r.onsuccess = () => res(r.result);
    r.onerror = () => res(null);
  });
}

/* ============ 11. 载入 / 演示数据 ============ */

function resetGraph() {
  for (const n of state.nodes.values()) n.el?.remove();
  state.nodes.clear();
  state.selected = null;
}

async function openVault() {
  if (!window.showDirectoryPicker) {
    flash('当前浏览器不支持本地文件夹读写，请用 Chrome / Edge 打开');
    return;
  }
  try {
    const dir = await window.showDirectoryPicker({ mode: 'readwrite' });
    await idbSet('dir', dir);
    await loadVault(dir);
  } catch (err) {
    if (err.name !== 'AbortError') flash('打开失败：' + err.message);
  }
}

async function loadVault(dir) {
  state.vault = dir;
  resetGraph();
  state.canvases.clear();
  state.activeCanvas = null;

  const noteFiles = [], canvasFiles = [];
  for await (const [name, h] of dir.entries()) {
    if (h.kind !== 'file' || !/\.md$/i.test(name)) continue;
    if (/\.canvas\.md$/i.test(name)) canvasFiles.push(name);
    else noteFiles.push(name);
  }

  for (const name of noteFiles) {
    try {
      const fh = await dir.getFileHandle(name);
      const file = await fh.getFile();
      const text = await file.text();
      const { fm, body } = parseNote(text);
      const n = {
        id: fm.id || uid(),
        title: fm.title || name.replace(/\.md$/i, ''),
        body,
        file: name,
        links: fm.rel.map((r) => ({ to: r.to, type: r.type || '', dir: r.dir === '0' ? 0 : 1 })),
        pos: null,
        legacy: parsePos(fm.pos),
        revealedBy: new Set(),
        updated: file.lastModified || Date.now(),
      };
      state.nodes.set(n.id, n);
    } catch (err) {
      console.warn('跳过', name, err);
    }
  }

  for (const name of canvasFiles) {
    try {
      const fh = await dir.getFileHandle(name);
      const text = await (await fh.getFile()).text();
      const c = parseCanvas(text, name);
      state.canvases.set(c.id, c);
    } catch (err) {
      console.warn('跳过画布', name, err);
    }
  }

  resolveLinks();
  buildAdj();

  if (!state.canvases.size) {
    const c = { id: 'c' + Math.random().toString(36).slice(2, 8), name: '主画布', file: null, placements: new Map() };
    state.canvases.set(c.id, c);
    c.file = canvasFileFor(c);
    const legacy = [...state.nodes.values()].filter((n) => n.legacy);
    if (legacy.length) {
      for (const n of legacy) c.placements.set(n.id, n.legacy);
    } else if (state.nodes.size) {
      seedLayout(c);
    }
  }

  const first = state.canvases.values().next().value;
  applyCanvas(first);
  fitView();
  updateCanvasBtn();
  if (!canvasFiles.length) writeCanvas(first);   // 首次打开：把迁移出的画布落盘
  flash('已载入 ' + state.nodes.size + ' 篇笔记 · ' + state.canvases.size + ' 块画布');
}

function resolveLinks() {
  const byTitle = new Map();
  for (const n of state.nodes.values()) byTitle.set(n.title, n.id);
  for (const n of state.nodes.values()) {
    n.links = n.links
      .map((l) => ({ to: state.nodes.has(l.to) ? l.to : (byTitle.get(l.to) || l.to), type: l.type || '', dir: l.dir === 0 ? 0 : 1 }))
      .filter((l) => l.to && l.to !== n.id);
  }
}

function seedLayout(c) {
  const list = [...state.nodes.values()].sort((a, b) => degree(b) - degree(a)).slice(0, 9);
  list.forEach((n, i) => {
    const angle = -Math.PI / 2 + (i / list.length) * Math.PI * 2;
    const r = i === 0 ? 0 : 300;
    c.placements.set(n.id, { x: 900 + Math.cos(angle) * r, y: 640 + Math.sin(angle) * r });
  });
}

/* ---- 演示模式 ---- */
const DEMO = [
  { t: 'Zettelkasten 卡片盒', x: 900, y: 640, b: '每张卡片只装一个想法，靠编号与链接把卡片织成网络。卡片盒不是仓库，而是对话对象——你写下的每一条，都是为了让未来的自己能接着往下想。\n\n关键动作：写完立刻建链，不要攒。' },
  { t: '原子化笔记', x: 600, y: 510, b: '一条笔记只表达一个完整意思，标题即结论。\n\n好处是可以被独立引用、独立重组；坏处是碎片太多时需要索引页兜底。' },
  { t: '双链与反链', x: 1200, y: 500, b: '正向链接是你主动写的引用，反向链接是系统告诉你"谁提过我"。\n\n反链的价值在于：你不需要记得自己写过什么，系统会替你回忆。' },
  { t: '知识图谱', x: 1350, y: 720, b: '把笔记当节点、关联当边。好看不是目的，能回答"这个概念和哪些东西连着"才是。\n\n节点超过几百个后，必须靠局部聚焦和筛选，否则图会变成毛线团。' },
  { t: '间隔重复', x: 620, y: 820, b: '按遗忘曲线安排复习。\n\n和卡片盒结合时，只复习你标记过的卡片，别把整个知识库变成题库。' },
  { t: 'PARA 方法', x: 900, y: 380, b: 'Projects / Areas / Resources / Archive 四层分类。\n\n它是"存放"逻辑，和卡片盒的"连接"逻辑互补：一个管秩序，一个管生长。' },
  { t: '渐进式总结', x: 1180, y: 880, b: '第一遍划线，第二遍加粗，第三遍写自己的话。\n\n每一层都在压缩信息，最后留下的是可以直接用的结论。' },
  { t: '语义网络', x: 1480, y: 460, b: '节点是概念，边是语义关系（是一种/导致/对比）。\n\n和知识图谱的差别在于：边是有类型的，类型本身就是知识。' },
  { t: '写作输出', x: 760, y: 900, b: '把卡片按论证顺序排列，就得到初稿。\n\n写作不是从空白页开始，而是从已有卡片里挑。' },
];
const DEMO_LINKS = [
  [0, 1, '前置知识'], [0, 2, '核心机制'], [2, 3, '延伸'], [1, 2, '支撑'],
  [4, 1, '相关'], [5, 0, '对比'], [6, 1, '延伸'], [3, 7, '相关'],
  [1, 8, '支撑'], [0, 6, '相关'],
];

function loadDemo() {
  state.vault = null;
  resetGraph();
  state.canvases.clear();
  state.activeCanvas = null;

  const stored = localStorage.getItem('starnote.demo.v2');
  if (stored) {
    try {
      const data = JSON.parse(stored);
      for (const raw of data.nodes) {
        state.nodes.set(raw.id, { ...raw, pos: null, revealedBy: new Set(), el: null });
      }
      resolveLinks();
      buildAdj();
      for (const c of data.canvases) {
        state.canvases.set(c.id, { id: c.id, name: c.name, file: c.file, placements: new Map(c.placements) });
      }
      if (state.canvases.size) {
        const active = state.canvases.get(data.active) || state.canvases.values().next().value;
        applyCanvas(active);
        fitView();
        return;
      }
    } catch (e) { /* 落回默认 */ }
  }

  const ids = DEMO.map(() => uid());
  DEMO.forEach((d, i) => {
    state.nodes.set(ids[i], {
      id: ids[i], title: d.t, body: d.b, links: [],
      pos: null, revealedBy: new Set(), el: null,
      updated: Date.now() - i * 36e5,
      file: d.t.replace(/[\\/:*?"<>|]/g, '-') + '.md',
    });
  });
  for (const [a, b, type] of DEMO_LINKS) {
    state.nodes.get(ids[a]).links.push({ to: ids[b], type, dir: 1 });
  }
  resolveLinks();
  buildAdj();

  const c1 = { id: 'c' + Math.random().toString(36).slice(2, 8), name: '知识地图', file: '知识地图.canvas.md', placements: new Map() };
  DEMO.forEach((d, i) => c1.placements.set(ids[i], { x: d.x, y: d.y }));

  const c2 = { id: 'c' + Math.random().toString(36).slice(2, 8), name: '写作线索', file: '写作线索.canvas.md', placements: new Map() };
  [[8, 760, 620], [1, 1040, 500], [6, 1040, 800], [0, 1320, 660]].forEach(([i, x, y]) => c2.placements.set(ids[i], { x, y }));

  state.canvases.set(c1.id, c1);
  state.canvases.set(c2.id, c2);

  applyCanvas(c1);
  fitView();
  saveDemo();
}

function saveDemo() {
  if (state.vault) return;
  snapshotActive();
  const data = {
    nodes: [...state.nodes.values()].map((n) => ({ id: n.id, title: n.title, body: n.body, file: n.file, links: n.links, updated: n.updated })),
    canvases: [...state.canvases.values()].map((c) => ({ id: c.id, name: c.name, file: c.file, placements: [...c.placements] })),
    active: state.activeCanvas ? state.activeCanvas.id : null,
  };
  try {
    localStorage.setItem('starnote.demo.v2', JSON.stringify(data));
    localStorage.removeItem('starnote.demo.v1');
  } catch (e) { /* 配额 */ }
}

/* ============ 12. 新建 / 搜索 / 提示 ============ */

function createNote(world) {
  const n = {
    id: uid(), title: '新笔记', body: '', links: [],
    pos: world || { x: 900, y: 640 },
    revealedBy: new Set(), el: null, updated: Date.now(), file: null,
  };
  state.nodes.set(n.id, n);
  if (state.activeCanvas) state.activeCanvas.placements.set(n.id, { x: n.pos.x, y: n.pos.y });
  renderAll();
  updateCanvasBtn();
  touchCanvas();
  select(n.id);
  openEditor(n);
  $('#editTitle').focus();
  $('#editTitle').select();
}

function flash(msg) {
  const hint = $('.hint');
  if (!hint) return;
  const old = hint.textContent;
  hint.textContent = msg;
  clearTimeout(flash.t);
  flash.t = setTimeout(() => { hint.textContent = old; }, 2200);
}

bindAsk();
$('#btnOpen').addEventListener('click', openVault);
$('#btnNew').addEventListener('click', () => {
  const r = stage.getBoundingClientRect();
  createNote(toWorld(r.left + r.width / 2, r.top + r.height / 2));
});
$('#btnFit').addEventListener('click', fitView);

$('#btnCanvas').addEventListener('click', (ev) => {
  ev.stopPropagation();
  if ($('#canvasMenu').classList.contains('show')) closeCanvasMenu();
  else openCanvasMenu();
});

$('#canvasMenu').addEventListener('click', async (ev) => {
  const del = ev.target.closest('.cm-del');
  if (del) {
    const c = state.canvases.get(del.dataset.id);
    if (c) await deleteCanvas(c);
    return;
  }
  const ren = ev.target.closest('.cm-rename');
  if (ren) {
    const c = state.canvases.get(ren.dataset.id);
    if (!c) return;
    const name = await askText('重命名画布', c.name);
    if (name) await renameCanvas(c, name);
    return;
  }
  if (ev.target.closest('#cmNew')) {
    const name = await askText('新建画布', '画布 ' + (state.canvases.size + 1));
    if (name) createCanvas(name);
    closeCanvasMenu();
    return;
  }
  const item = ev.target.closest('.cm-item');
  if (!item) return;
  const c = state.canvases.get(item.dataset.id);
  if (c && c !== state.activeCanvas) switchCanvas(c);
  else closeCanvasMenu();
});
$('#search').addEventListener('input', (ev) => {
  state.search = ev.target.value;
  renderAll();
});
$('#search').addEventListener('keydown', (ev) => {
  if (ev.key !== 'Enter') return;
  const q = state.search.trim().toLowerCase();
  if (!q) return;
  const hit = [...state.nodes.values()].find((n) => (n.title + ' ' + (n.body || '')).toLowerCase().includes(q));
  if (hit) { select(hit.id); focusOn(hit); }
});

document.addEventListener('keydown', (ev) => {
  const meta = ev.metaKey || ev.ctrlKey;
  if (meta && ev.key.toLowerCase() === 's' && state.editing) { ev.preventDefault(); saveEditor(); return; }
  if (ev.key === 'Escape') {
    if ($('#canvasMenu').classList.contains('show')) { closeCanvasMenu(); return; }
    if (popover.classList.contains('show')) { closePopover(); return; }
    if (ctxmenu.classList.contains('show')) { closeMenu(); return; }
    if ($('#editor').classList.contains('open')) { closeEditor(); return; }
    select(null);
  }
  if (ev.key === 'Enter' && state.selected && !state.editing && document.activeElement.tagName !== 'INPUT') {
    const n = state.nodes.get(state.selected);
    if (n) openEditor(n);
  }
});

/* ============ 13. 启动 ============ */

(async function init() {
  let dir = null;
  try {
    const saved = await idbGet('dir');
    if (saved && (await saved.queryPermission({ mode: 'readwrite' })) === 'granted') dir = saved;
  } catch (e) { /* 忽略 */ }

  if (dir) {
    loadVault(dir);
  } else {
    loadDemo();
    if (window.showDirectoryPicker) flash('演示数据 · 点「打开文件夹」载入你自己的 Markdown');
  }

  window.addEventListener('resize', () => { /* 视图不随窗口缩放，保持用户视角 */ });
})();
